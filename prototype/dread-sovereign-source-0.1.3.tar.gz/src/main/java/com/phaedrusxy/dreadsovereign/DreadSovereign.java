package com.phaedrusxy.dreadsovereign;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(DreadSovereign.MOD_ID)
public final class DreadSovereign {
    public static final String MOD_ID = "dreadsovereign";
    public static final Logger LOGGER = LogUtils.getLogger();

    public DreadSovereign(IEventBus modBus) {
        ModRituals.REGISTRY.register(modBus);

        NeoForge.EVENT_BUS.addListener(DreadSovereignCommands::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(EncounterManager::onEntityJoinLevel);
        NeoForge.EVENT_BUS.addListener(EncounterManager::onServerTick);
        NeoForge.EVENT_BUS.addListener(EncounterManager::onLivingDamage);
        NeoForge.EVENT_BUS.addListener(EncounterManager::onLivingDeath);
    }
}
