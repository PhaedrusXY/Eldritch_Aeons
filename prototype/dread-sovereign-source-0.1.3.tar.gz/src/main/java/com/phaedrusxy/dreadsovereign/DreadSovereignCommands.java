package com.phaedrusxy.dreadsovereign;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

final class DreadSovereignCommands {
    private DreadSovereignCommands() {
    }

    static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("dreadsovereign")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(Commands.literal("spawn")
                        .executes(context -> spawn(context.getSource())))
                .then(Commands.literal("status")
                        .executes(context -> status(context.getSource())))
                .then(Commands.literal("force_resurrection")
                        .executes(context -> forceResurrection(context.getSource())))
                .then(Commands.literal("force_unbound")
                        .executes(context -> forceUnbound(context.getSource())))
                .then(Commands.literal("cleanup")
                        .executes(context -> cleanup(context.getSource()))));
    }

    private static int spawn(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        BlockPos pos = BlockPos.containing(source.getPosition());
        ServerPlayer player = source.getEntity() instanceof ServerPlayer serverPlayer ? serverPlayer : null;
        boolean spawned = EncounterManager.spawnEncounter(level, pos, player);
        source.sendSuccess(() -> Component.literal(spawned
                ? "Spawned the Dread Queen and Black Frost."
                : "An active encounter already exists nearby, or a required entity type is missing."), false);
        return spawned ? 1 : 0;
    }

    private static int status(CommandSourceStack source) {
        Component status = EncounterManager.status(source.getLevel(), source.getPosition());
        source.sendSuccess(() -> status, false);
        return 1;
    }

    private static int forceResurrection(CommandSourceStack source) {
        boolean changed = EncounterManager.debugForceResurrection(source.getLevel(), source.getPosition());
        source.sendSuccess(() -> Component.literal(changed
                ? "Forced Black Frost's defeat/resurrection transition."
                : "No suitable active encounter was found."), false);
        return changed ? 1 : 0;
    }

    private static int forceUnbound(CommandSourceStack source) {
        boolean changed = EncounterManager.debugForceUnbound(source.getLevel(), source.getPosition());
        source.sendSuccess(() -> Component.literal(changed
                ? "Forced the unbound Black Frost phase."
                : "No suitable active encounter was found."), false);
        return changed ? 1 : 0;
    }

    private static int cleanup(CommandSourceStack source) {
        int removed = EncounterManager.cleanup(source.getLevel(), source.getPosition(), 256.0);
        source.sendSuccess(() -> Component.literal("Removed " + removed + " Dread Sovereign encounter(s)."), false);
        return removed;
    }
}
