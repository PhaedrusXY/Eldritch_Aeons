package com.phaedrusxy.dreadsovereign;

import com.klikli_dev.occultism.common.blockentity.GoldenSacrificialBowlBlockEntity;
import com.klikli_dev.occultism.common.ritual.Ritual;
import com.klikli_dev.occultism.crafting.recipe.RitualRecipe;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

final class DreadSovereignRitual extends Ritual {
    private static final Identifier FINAL_BOSS_SPAWNER =
            Identifier.fromNamespaceAndPath("twilightforest", "final_boss_boss_spawner");
    private static final String TWILIGHT_DIMENSION = "twilightforest:twilight_forest";

    DreadSovereignRitual(RitualRecipe recipe) {
        super(recipe);
    }

    @Override
    public boolean isValid(Level level, BlockPos goldenBowlPosition,
                           GoldenSacrificialBowlBlockEntity blockEntity,
                           @Nullable Player castingPlayer, ItemStack activationItem,
                           List<Ingredient> remainingAdditionalIngredients) {
        return super.isValid(level, goldenBowlPosition, blockEntity, castingPlayer, activationItem,
                remainingAdditionalIngredients)
                && level instanceof ServerLevel serverLevel
                && TWILIGHT_DIMENSION.equals(level.dimension().identifier().toString())
                && ReflectionBridge.getDragonSkullStage(activationItem) >= 5
                && isNearFinalBossSpawner(level, goldenBowlPosition)
                && !EncounterManager.hasActiveEncounter(serverLevel, goldenBowlPosition, 128.0);
    }

    @Override
    public boolean consumeAdditionalIngredients(Level level, BlockPos goldenBowlPosition,
                                                List<Ingredient> remainingAdditionalIngredients,
                                                int time, List<ItemStack> consumedIngredients) {
        // The eight trophies are permanent ritual fixtures. Only the central dragon skull is consumed.
        return true;
    }

    @Override
    public void markNextIngredient(Level level, BlockPos goldenBowlPosition, Ingredient ingredient, int tier) {
        // Deliberately suppress Occultism's single-bowl consumption marker: no trophy is consumed.
    }

    @Override
    public void update(Level level, BlockPos goldenBowlPosition,
                       GoldenSacrificialBowlBlockEntity blockEntity,
                       @Nullable Player castingPlayer, ItemStack activationItem, int time) {
        if (level instanceof ServerLevel serverLevel && level.getGameTime() % 10 == 0) {
            serverLevel.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    goldenBowlPosition.getX() + 0.5,
                    goldenBowlPosition.getY() + 0.8,
                    goldenBowlPosition.getZ() + 0.5,
                    12, 1.8, 0.4, 1.8, 0.015);
            serverLevel.sendParticles(ParticleTypes.SNOWFLAKE,
                    goldenBowlPosition.getX() + 0.5,
                    goldenBowlPosition.getY() + 1.2,
                    goldenBowlPosition.getZ() + 0.5,
                    8, 1.4, 0.8, 1.4, 0.01);
        }
    }

    @Override
    public void finish(Level level, BlockPos goldenBowlPosition,
                       GoldenSacrificialBowlBlockEntity blockEntity,
                       @Nullable ServerPlayer castingPlayer, ItemStack activationItem) {
        super.finish(level, goldenBowlPosition, blockEntity, castingPlayer, activationItem);
        activationItem.shrink(1);
        if (level instanceof ServerLevel serverLevel) {
            EncounterManager.spawnEncounter(serverLevel, goldenBowlPosition, castingPlayer);
        }
    }

    private static boolean isNearFinalBossSpawner(Level level, BlockPos center) {
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-16, -8, -16), center.offset(16, 8, 16))) {
            Identifier id = BuiltInRegistries.BLOCK.getKey(level.getBlockState(pos).getBlock());
            if (FINAL_BOSS_SPAWNER.equals(id)) {
                return true;
            }
        }
        return false;
    }
}
