package com.phaedrusxy.dreadsovereign;

import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

final class ReflectionBridge {
    private static final Identifier DRAGON_SKULL_COMPONENT =
            Identifier.fromNamespaceAndPath("iceandfire", "dragon_skull");
    private static final Set<String> LOGGED_FAILURES = new HashSet<>();

    private ReflectionBridge() {
    }

    static void configureBlackFrost(Mob dragon) {
        invoke(dragon, "setAgeInDays", new Class<?>[]{int.class}, 125);
        invoke(dragon, "setAgingDisabled", new Class<?>[]{boolean.class}, true);
        invoke(dragon, "setVariant", new Class<?>[]{String.class}, "silver");
        invoke(dragon, "setGender", new Class<?>[]{boolean.class}, false);
        invoke(dragon, "refreshDirtyAttributes", new Class<?>[0]);
    }

    static Vec3 getDragonRiderPosition(LivingEntity dragon) {
        try {
            Method method = dragon.getClass().getMethod("getRiderPosition");
            Object value = method.invoke(dragon);
            if (value instanceof Vec3 position) {
                return position;
            }
        } catch (ReflectiveOperationException exception) {
            logOnce(dragon.getClass().getName() + "#getRiderPosition", exception);
        }
        return dragon.position().add(0.0D, Math.max(2.0D, dragon.getBbHeight() * 0.65D), 0.0D);
    }

    static void setDragonDeadModel(LivingEntity dragon, boolean dead) {
        invoke(dragon, "setModelDead", new Class<?>[]{boolean.class}, dead);
        if (!dead) {
            invoke(dragon, "setDeathStage", new Class<?>[]{int.class}, 0);
        }
    }

    static void setDragonFlight(Mob dragon, boolean flying) {
        invoke(dragon, "setFlying", new Class<?>[]{boolean.class}, flying);
        invoke(dragon, "setHovering", new Class<?>[]{boolean.class}, flying);
        if (flying) {
            invoke(dragon, "switchNavigator", new Class<?>[]{int.class}, 1);
        }
    }

    static void setCommander(Mob minion, UUID commander) {
        invoke(minion, "setCommanderId", new Class<?>[]{UUID.class}, commander);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    static int getDragonSkullStage(ItemStack stack) {
        DataComponentType type = BuiltInRegistries.DATA_COMPONENT_TYPE.getValue(DRAGON_SKULL_COMPONENT);
        if (type == null) {
            return -1;
        }
        Object component = stack.get(type);
        if (component == null) {
            return -1;
        }
        try {
            Method accessor = component.getClass().getMethod("stage");
            Object value = accessor.invoke(component);
            return value instanceof Number number ? number.intValue() : -1;
        } catch (ReflectiveOperationException exception) {
            logOnce(component.getClass().getName() + "#stage", exception);
            return -1;
        }
    }

    private static void invoke(Object target, String methodName, Class<?>[] parameterTypes, Object... arguments) {
        try {
            Method method = target.getClass().getMethod(methodName, parameterTypes);
            method.invoke(target, arguments);
        } catch (ReflectiveOperationException exception) {
            logOnce(target.getClass().getName() + "#" + methodName, exception);
        }
    }

    private static void logOnce(String key, Exception exception) {
        if (LOGGED_FAILURES.add(key)) {
            DreadSovereign.LOGGER.warn("Optional integration call {} failed; the encounter will continue with reduced behavior.", key, exception);
        }
    }
}
